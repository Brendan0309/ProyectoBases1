--Ejercicio #5
SELECT DISTINCT p.person_id,
       p.primerNombre,
       p.primerApellido
FROM People p
JOIN Phone ph ON p.person_id = ph.person_id
JOIN Phonetype pt ON ph.phonetype_id = pt.phonetype_id
WHERE pt.name = 'Casa';
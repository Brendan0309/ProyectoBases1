--Ejercicio #11
SELECT p.person_id,
       p.primerNombre || ' ' || p.primerApellido AS cliente,
       COUNT(c.compra_id) AS total_compras
FROM People p
JOIN Compra c ON p.person_id = c.person_id
GROUP BY p.person_id, p.primerNombre, p.primerApellido
HAVING COUNT(c.compra_id) > 2;
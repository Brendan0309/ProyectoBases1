--Ejercicio #9 
SELECT COUNT(*) AS total_clientes
FROM People
WHERE peopletype_id = 1;

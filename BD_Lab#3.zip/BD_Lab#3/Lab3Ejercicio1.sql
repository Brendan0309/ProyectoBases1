--Ejercicio #1
SELECT COUNT(*) AS total_personas
FROM People;
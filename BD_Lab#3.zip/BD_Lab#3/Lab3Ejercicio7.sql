--Ejercicio7
--a
CREATE OR REPLACE VIEW vw_top3_rownum AS
SELECT rownum id, primerNombre || ' ' || primerApellido AS nombre, salario
FROM (
    SELECT primerNombre, primerApellido, salario
    FROM People
    ORDER BY salario DESC
)
WHERE rownum <= 3;

--b
CREATE OR REPLACE VIEW vw_top3_rank AS
SELECT primerNombre || ' ' || primerApellido AS nombre, salario
FROM (
    SELECT primerNombre, primerApellido, salario,
           RANK() OVER (ORDER BY salario DESC) salario_rank
    FROM People
)
WHERE salario_rank <= 3;


--Diferencias
--ROWNUM corta las primeras 3 filas, aunque haya empates en salario.
--RANK() incluye todos los empates en la misma posición, por lo que puede devolver más de 3 personas si varios tienen el mismo salario en el top.
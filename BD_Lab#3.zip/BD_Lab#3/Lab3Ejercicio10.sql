--Ejercicio #10
SELECT p.person_id,
       p.primerNombre || ' ' || p.primerApellido AS cliente,
       pr.nombre AS producto,
       SUM(cd.cantidad) AS total_comprado
FROM People p
JOIN Compra c ON p.person_id = c.person_id
JOIN CompraDetalle cd ON c.compra_id = cd.compra_id
JOIN Producto pr ON cd.producto_id = pr.producto_id
GROUP BY p.person_id, p.primerNombre, p.primerApellido, pr.nombre
ORDER BY cliente;
--Ejercicio #4
SELECT p.person_id,
       p.primerNombre,
       COUNT(ph.phone_id) AS total_telefonos
FROM People p
LEFT JOIN Phone ph ON p.person_id = ph.person_id
GROUP BY p.person_id, p.primerNombre;
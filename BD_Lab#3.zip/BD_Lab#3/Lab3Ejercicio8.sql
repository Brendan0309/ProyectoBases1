--Ejercicio #8
SELECT COUNT(DISTINCT person_id) AS clientes_con_compras
FROM Compra;
--Ejercicio #2
SELECT *
FROM People
WHERE primerNombre LIKE 'B%';
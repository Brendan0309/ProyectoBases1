--Ejercicio #6
-- antes de ejecutar se debe ir a sqlplus / as sysdba y otorgarle permisos
-- GRANT CREATE VIEW TO ge;
CREATE OR REPLACE VIEW vw_personas_menos_3000 AS
SELECT person_id, primerNombre, primerApellido, salario
FROM People
WHERE salario < 3000;

--Ejercicio #3
SELECT *
FROM People
WHERE primerNombre LIKE 'b%';